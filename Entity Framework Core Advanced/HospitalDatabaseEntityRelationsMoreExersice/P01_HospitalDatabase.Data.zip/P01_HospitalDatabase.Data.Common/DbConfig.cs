﻿

namespace P01_HospitalDatabase.Data.Common;

public class DbConfig

{
    public const string ConnectionString = 
        @"Server=DESKTOP-88S8DPK\\SQLEXPRESS01;Database=HospitalDataBase;Integrated Security=true;TrustServerCertificate=true;";
}