﻿


namespace P01_HospitalDatabase.Data.Common;

public class ValidationConstants
{

    //patient
    public const int PatientFirstnameMaxLenght = 50;
    public const int PatientLastNAMEMaxLength = 50;
    public const int PatientAddressMaxlenght = 250;
    public const int PatienEmailMaxLenght = 80;
    // visitations
    public const int VisitationsCommnetsMaxLenght = 250;
    //dIAGNOSE
    public const int DiagnoseNameMaxLength = 50;
    public const int DiagnoseCommentMaxlenght = 250;
    //medicamnet
    public const int MedicamentNameMaxLENGTH = 50;
}
