﻿

namespace StydentSystem.Data.Common;

public static  class DbConfig
{
    public const string ConnectionString = 
        @"Server=DESKTOP-88S8DPK\SQLEXPRESS01;Database=Students;Integrated Security=true;TrustServerCertificate=true;";
}