﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-88S8DPK\SQLEXPRESS01;Database=ProductShop;Integrated Security=true;TrustServerCertificate=true";
    }
}
