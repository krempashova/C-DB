﻿

namespace P02_FootballBetting.Data.Models.Enum;

public enum Prediction
{
       Draw = 0,
        Win = 1,
        Lose = 2
}
