﻿using System.Data.Common;

namespace P02_FootballBetting.Data.Common
{
    public  static class DbConfig


    {
        public const string ConnectionString =
            @"Server=DESKTOP-88S8DPK\SQLEXPRESS01;Database=Bet365;Integrated Security=True;Encrypt=False;";
    }
}