﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-88S8DPK\SQLEXPRESS01;Database=Invoices;Integrated Security=true;TrustServerCertificate=true";
    }
}
