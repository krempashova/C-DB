﻿
namespace Boardgames.Common;

public static  class Validations
{

    //seller
    public const string websiteRegexValidation = @"^www\.[a-zA-Z0-9-]+.com";
}
