﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-88S8DPK\SQLEXPRESS01;Database=Boardgames;Integrated Security=True;Encrypt=False";
    }
}
