﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-88S8DPK\SQLEXPRESS01;Database=FootballersExam;Trusted_Connection=True";
    }
}
