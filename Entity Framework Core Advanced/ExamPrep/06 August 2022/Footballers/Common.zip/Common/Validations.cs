﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Footballers.Common
{
    public static class Validations
    {
        // Teams
        public const string RegexNameTeams= @"^[A-Za-z0-9.\s-]+$";
    }
}
