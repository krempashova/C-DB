﻿
namespace Cadastre.Common;

public static  class Validation
{

    //NAMEDistrict
    public const string RegexPostalCode= @"^[A-Z]{2}-\d{5}";

    public const string regexMarital = @"";
}
