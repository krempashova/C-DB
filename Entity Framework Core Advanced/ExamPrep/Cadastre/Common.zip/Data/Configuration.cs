﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-88S8DPK\SQLEXPRESS01;Database=Cadastre;Integrated Security=true;TrustServerCertificate=true;";
    }
}
