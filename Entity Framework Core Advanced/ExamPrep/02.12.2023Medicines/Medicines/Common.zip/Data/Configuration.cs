﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-88S8DPK\SQLEXPRESS01;Database=Medicines;Integrated Security=true;TrustServerCertificate=true;";

    }
}
