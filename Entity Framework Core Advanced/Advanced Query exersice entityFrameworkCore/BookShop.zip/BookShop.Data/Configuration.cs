﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString=>
           "Server=DESKTOP-88S8DPK\\SQLEXPRESS01;Database=BookShop;Integrated Security = true; TrustServerCertificate=true";
    }
}
